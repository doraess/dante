#ifndef UTIL_H
#define UTIL_H
	

	
char *itoa(int i);
char *strchar(char *s, int c);

#endif 